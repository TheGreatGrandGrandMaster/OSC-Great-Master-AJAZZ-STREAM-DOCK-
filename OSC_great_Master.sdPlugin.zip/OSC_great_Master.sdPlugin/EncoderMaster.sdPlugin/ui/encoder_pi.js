let websocket = null;
let uuid = null;
let context = null;
let settings = {};

function sendToSD(payload) {
  if (!websocket || websocket.readyState !== 1) return;
  websocket.send(JSON.stringify(payload));
}

function setSettings(newSettings) {
  settings = { ...(settings||{}), ...(newSettings||{}) };
  sendToSD({ event: "setSettings", context, payload: settings });
}

function requestSettings() {
  sendToSD({ event: "getSettings", context });
}

function safeStr(v, defV) {
  return (typeof v === "string" && v.trim().length) ? v.trim() : defV;
}
function intVal(v, defV) {
  const n = parseInt(v, 10);
  return Number.isFinite(n) ? n : defV;
}

function normalizeNet(s) {
  s = s || {};
  return {
    ip: safeStr(s.ip, "127.0.0.1"),
    port: intVal(s.port, 8000)
  };
}

window.connectElgatoStreamDeckSocket = function(inPort, inUuid, inRegisterEvent, inInfo, inActionInfo) {
  uuid = inUuid;
  try {
    const actionData = JSON.parse(inActionInfo);
    context = actionData.context || uuid;
    settings = (actionData.payload && actionData.payload.settings) ? actionData.payload.settings : {};
  } catch(e) {
    context = uuid;
    settings = {};
  }

  websocket = new WebSocket(`ws://127.0.0.1:${inPort}`);

  websocket.onopen = function() {
    sendToSD({ event: inRegisterEvent, uuid });
    requestSettings();
    applyToUI(settings);
    bindUI();
  };

  websocket.onmessage = function(evt) {
    const msg = JSON.parse(evt.data);
    if (msg.event === "didReceiveSettings") {
      settings = (msg.payload && msg.payload.settings) ? msg.payload.settings : {};
      applyToUI(settings);
    }
  };
};

// to be defined per-PI:
function applyToUI(s) {}
function bindUI() {}
function gatherSettings() { return {}; }
function $(id){ return document.getElementById(id); }

function applyToUI(s){
  const net = normalizeNet(s);
  $("ip").value = net.ip;
  $("port").value = net.port;
  $("wheel").value = String(intVal(s.wheel, 1));
}

function gatherSettings(){
  return {
    ip: safeStr($("ip").value, "127.0.0.1"),
    port: intVal($("port").value, 8000),
    wheel: intVal($("wheel").value, 1)
  };
}

function bindUI(){
  $("ip").addEventListener("input", () => setSettings(gatherSettings()));
  $("port").addEventListener("input", () => setSettings(gatherSettings()));
  $("wheel").addEventListener("change", () => setSettings(gatherSettings()));
}
